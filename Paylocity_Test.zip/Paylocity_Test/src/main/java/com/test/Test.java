package com.test;

import java.io.File;
import java.io.FileWriter;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Test {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		FileWriter csvWriter = new FileWriter(new File("target/paylocity_test_results.csv")); 
		csvWriter.write("Test Case, Expected Result, Actual Result, Status \n");
		
		testCase1(driver,csvWriter);
		testCase2(driver,csvWriter);
		testCase3(driver,csvWriter,args[0],args[1]);
		
		csvWriter.close();
		//driver.quit();
		
	}
	
	public static void testCase1(WebDriver driver,FileWriter csvWriter) throws Exception {
		driver.get("https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod/Account/Login");
		// Find User name from driver and set user name
		driver.findElement(By.id("Username")).sendKeys("");
		//Find Password and set PAssword
		driver.findElement(By.name("Password")).sendKeys("Password");
		driver.findElement(By.xpath("/html/body/div/main/div/div/form/button")).click();
		String expected_title = "Log In - Paylocity Benefits Dashboard" ;
		String actual_title = driver.getTitle();
		
		boolean testStatus = false;
		if ( expected_title.equals(actual_title) ) {
			System.out.println("testCase1 -- Test Passed");
		    testStatus = true;
		}else
		{
			System.out.println("testCase1 -- Test Failed");
		}
		csvWriter.write("Blank Username/invalid password,"
				+ "Page title must be 'Log In - Paylocity Benefits Dashboard',"
				+ actual_title+","+testStatus+"\n");
	}
	
	public static void testCase2(WebDriver driver,FileWriter csvWriter) throws Exception {
		driver.get("https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod/Account/Login");
		// Find User name from driver and set user name
		driver.findElement(By.id("Username")).sendKeys("Nim09");
		//Find Password and set PAssword
		driver.findElement(By.name("Password")).sendKeys("Password");
		driver.findElement(By.xpath("/html/body/div/main/div/div/form/button")).click();
		String expected_title = "Log In - Paylocity Benefits Dashboard" ;
		String actual_title = driver.getTitle();
		boolean testStatus = false;
		if ( expected_title.equals(actual_title) ) {
			System.out.println("testCase2 -- Test Passed");
			testStatus=true;
		}
		else
		{
			System.out.println("testCase2 -- Test Failed");
		}
		csvWriter.write("Invalid Username/invalid password,"
				+ "Page title must be 'Log In - Paylocity Benefits Dashboard',"
				+ actual_title+","+testStatus+"\n");
	}
	//Test Case 3 - 
	public static void testCase3(WebDriver driver,FileWriter csvWriter,String uname,
			String pwd) throws Exception {
		driver.get("https://wmxrwq14uc.execute-api.us-east-1.amazonaws.com/Prod/Account/Login");
		// Find User name from driver and set user name
		driver.findElement(By.id("Username")).sendKeys(uname);
		//Find Password and set PAssword
		driver.findElement(By.name("Password")).sendKeys(pwd);
		driver.findElement(By.xpath("/html/body/div/main/div/div/form/button")).click();
		String expected_title = "Employees - Paylocity Benefits Dashboard" ;
		String actual_title = driver.getTitle();
		boolean testStatus = false;
		if ( expected_title.equals(actual_title) ) {
			System.out.println("testCase3 -- Test Passed");
			testStatus=true;
			csvWriter.write("Valid Username/Valid password,"
					+ "Page title must be 'Employees - Paylocity Benefits Dashboard',"
					+ actual_title+","+testStatus+"\n");
			
			//Test Case 4 - Add employee //*[@id="add"]
			driver.findElement(By.id("add")).click();
			driver.findElement(By.id("firstName")).sendKeys("Daisy");
			driver.findElement(By.id("lastName")).sendKeys("Miller");
			driver.findElement(By.id("dependants")).sendKeys("3");
			driver.findElement(By.id("addEmployee")).click();
			
			//Get the id, firstName, lastName, BenefitsCost, Net
			//Test Case 5- Validate First name and LAst Name
			////*[@id="employeesTable	"]/tbody/tr/td[1]    //*[@id="employeesTable"]/tbody/tr/td[3]
			
			//wait and refresh to get the data from data table.
			driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
			driver.navigate().refresh();
			
			String rowText = driver.findElement(By.xpath("//*[@id=\"employeesTable\"]/tbody/tr")).getText();
			System.out.println("rowText" + rowText);
			
			//*[@id="employeesTable"]/tbody/tr/td[1]
			String empId = driver.findElement(By.xpath("//*[@id=\"employeesTable\"]/tbody/tr[1]/td[1]")).getText();
			String lName = driver.findElement(By.xpath("//*[@id=\"employeesTable\"]/tbody/tr[1]/td[2]")).getText();
			String fName = driver.findElement(By.xpath("//*[@id=\"employeesTable\"]/tbody/tr[1]/td[3]")).getText();
			
			testStatus=false;
			if ( lName.equals("Miller") ) {
				System.out.println("testCase5 -- Test Passed");
				testStatus=true;
			}
			else {
				System.out.println("testCase5 -- Test Failed");
			}
			
			csvWriter.write("Validate lastName,"
					+ "lastName must be Miller,"
					+ lName +","+testStatus+"\n");
			
			testStatus=false;
			if ( fName.equals("Daisy") ) {
				System.out.println("testCase6 -- Test Passed");
				testStatus=true;
			}
			else {
				System.out.println("testCase6 -- Test Failed");
			}
			csvWriter.write("Validate firstName,"
					+ "firstName must be Daisy,"
					+ fName +","+testStatus+"\n");
			
		/*	//Test Case 7 -- Update Employee
			driver.findElement(By.xpath("//*[@id=\"employeesTable\"]/tbody/tr[1]/td[9]/i[1]")).click();
			driver.findElement(By.id("firstName")).clear();
			driver.findElement(By.id("firstName")).sendKeys("Samuel");
			driver.findElement(By.id("lastName")).clear();
			driver.findElement(By.id("lastName")).sendKeys("Jackson");
			driver.findElement(By.id("dependants")).clear();
			driver.findElement(By.id("dependants")).sendKeys("3");
			driver.findElement(By.id("updateEmployee")).click();
		
			//Test Case 8 -- Delete Employee
			driver.findElement(By.xpath("//*[@id=\"employeesTable\"]/tbody/tr[1]/td[9]/i[2]")).click();
			driver.findElement(By.id("deleteEmployee")).click();
		*/	
		}
		
		else
		{
			System.out.println("testCase3 -- Test Failed");
		}
	}
}
